from setuptools import setup

setup(name='spmmtb',
	  version='2.0',
	  description='Simple math module with: add, substract, multiply, divide only, usage: action(first, second)',
	  packages=['spmmtb'],
	  author='ReGamer45',
	  author_email='t.belf2020@gmail.com',
	  url='https://github.com/ReGamer45/spmmtb',
	  zip_safe=False)