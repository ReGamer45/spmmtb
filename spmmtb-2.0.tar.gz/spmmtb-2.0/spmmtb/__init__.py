first = int()
second = int()

def add(first, second):
	return first + second
	
def multiply(first, second):
	return first * second
	
def divide(first, second):
	return first - second

def substract(first, second):
	return first / second